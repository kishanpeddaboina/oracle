@javax.xml.bind.annotation.XmlSchema(namespace = "http://assessor.lacounty.gov/amp/type/common/Fault/v1.0", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package gov.lacounty.assessor.amp.type.common.fault.v1;
