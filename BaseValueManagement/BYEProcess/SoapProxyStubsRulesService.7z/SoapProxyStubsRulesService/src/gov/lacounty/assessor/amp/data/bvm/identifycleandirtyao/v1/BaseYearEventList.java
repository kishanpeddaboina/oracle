
package gov.lacounty.assessor.amp.data.bvm.identifycleandirtyao.v1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import gov.lacounty.assessor.amp.type.bvm.baseyearevent.v1.BaseYearEvent;


/**
 * <p>Java class for BaseYearEventList complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BaseYearEventList">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="baseYearEvent" type="{http://assessor.lacounty.gov/amp/type/bvm/BaseYearEvent/v1.0}baseYearEvent" minOccurs="0"/>
 *         &lt;element name="asmtRollId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="subUnitNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BaseYearEventList", propOrder = {
    "baseYearEvent",
    "asmtRollId",
    "subUnitNumber"
})
public class BaseYearEventList {

    protected BaseYearEvent baseYearEvent;
    protected String asmtRollId;
    protected String subUnitNumber;

    /**
     * Gets the value of the baseYearEvent property.
     * 
     * @return
     *     possible object is
     *     {@link BaseYearEvent }
     *     
     */
    public BaseYearEvent getBaseYearEvent() {
        return baseYearEvent;
    }

    /**
     * Sets the value of the baseYearEvent property.
     * 
     * @param value
     *     allowed object is
     *     {@link BaseYearEvent }
     *     
     */
    public void setBaseYearEvent(BaseYearEvent value) {
        this.baseYearEvent = value;
    }

    /**
     * Gets the value of the asmtRollId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAsmtRollId() {
        return asmtRollId;
    }

    /**
     * Sets the value of the asmtRollId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAsmtRollId(String value) {
        this.asmtRollId = value;
    }

    /**
     * Gets the value of the subUnitNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubUnitNumber() {
        return subUnitNumber;
    }

    /**
     * Sets the value of the subUnitNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubUnitNumber(String value) {
        this.subUnitNumber = value;
    }

}
