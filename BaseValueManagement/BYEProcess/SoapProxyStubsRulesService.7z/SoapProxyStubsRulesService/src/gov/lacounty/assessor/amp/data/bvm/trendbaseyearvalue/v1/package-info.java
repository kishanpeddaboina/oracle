@javax.xml.bind.annotation.XmlSchema(namespace = "http://assessor.lacounty.gov/amp/data/bvm/TrendBaseYearValue/v1.0", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package gov.lacounty.assessor.amp.data.bvm.trendbaseyearvalue.v1;
