
package gov.lacounty.assessor.amp.data.bvm.identifycleandirtyao.v1;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for AsmtList complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AsmtList">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="applicationId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="operationInput" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sysdate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="byeList" type="{http://assessor.lacounty.gov/amp/data/bvm/IdentifyCleanDirtyAO/v1.0}BaseYearEventList" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="asmtRollList" type="{http://assessor.lacounty.gov/amp/data/bvm/IdentifyCleanDirtyAO/v1.0}AsmtRollList" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="landList" type="{http://assessor.lacounty.gov/amp/data/bvm/IdentifyCleanDirtyAO/v1.0}LandList" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="histList" type="{http://assessor.lacounty.gov/amp/data/bvm/IdentifyCleanDirtyAO/v1.0}HistList" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AsmtList", propOrder = {
    "applicationId",
    "id",
    "operationInput",
    "sysdate",
    "byeList",
    "asmtRollList",
    "landList",
    "histList"
})
public class AsmtList {

    protected String applicationId;
    protected BigInteger id;
    protected String operationInput;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar sysdate;
    protected List<BaseYearEventList> byeList;
    protected List<AsmtRollList> asmtRollList;
    protected List<LandList> landList;
    protected List<HistList> histList;

    /**
     * Gets the value of the applicationId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationId() {
        return applicationId;
    }

    /**
     * Sets the value of the applicationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationId(String value) {
        this.applicationId = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setId(BigInteger value) {
        this.id = value;
    }

    /**
     * Gets the value of the operationInput property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperationInput() {
        return operationInput;
    }

    /**
     * Sets the value of the operationInput property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperationInput(String value) {
        this.operationInput = value;
    }

    /**
     * Gets the value of the sysdate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSysdate() {
        return sysdate;
    }

    /**
     * Sets the value of the sysdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setSysdate(XMLGregorianCalendar value) {
        this.sysdate = value;
    }

    /**
     * Gets the value of the byeList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the byeList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getByeList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BaseYearEventList }
     * 
     * 
     */
    public List<BaseYearEventList> getByeList() {
        if (byeList == null) {
            byeList = new ArrayList<BaseYearEventList>();
        }
        return this.byeList;
    }

    /**
     * Gets the value of the asmtRollList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the asmtRollList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAsmtRollList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AsmtRollList }
     * 
     * 
     */
    public List<AsmtRollList> getAsmtRollList() {
        if (asmtRollList == null) {
            asmtRollList = new ArrayList<AsmtRollList>();
        }
        return this.asmtRollList;
    }

    /**
     * Gets the value of the landList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the landList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLandList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LandList }
     * 
     * 
     */
    public List<LandList> getLandList() {
        if (landList == null) {
            landList = new ArrayList<LandList>();
        }
        return this.landList;
    }

    /**
     * Gets the value of the histList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the histList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getHistList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link HistList }
     * 
     * 
     */
    public List<HistList> getHistList() {
        if (histList == null) {
            histList = new ArrayList<HistList>();
        }
        return this.histList;
    }

}
